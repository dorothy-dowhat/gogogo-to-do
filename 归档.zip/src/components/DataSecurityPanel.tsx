import { useState } from 'react';

export default function DataSecurityPanel() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="data-security-panel">
      <button
        className="security-toggle"
        onClick={() => setIsOpen(!isOpen)}
      >
        🔒 {isOpen ? '收起' : '数据安全'}
      </button>

      {isOpen && (
        <div className="security-content">
          <h4>📋 数据保存说明</h4>
          <ul>
            <li>• 数据仅保存在您当前浏览器的本地，不会上传到服务器</li>
            <li>• 关闭浏览器、重启电脑，数据不会丢失</li>
            <li>• 以下情况会导致数据丢失：
              <ol className="numbered-list">
                <li>手动清除浏览器缓存、网站数据</li>
                <li>使用无痕/隐私模式访问本网站</li>
                <li>更换设备、更换浏览器访问</li>
                <li>卸载或重置浏览器</li>
              </ol>
            </li>
            <li>• 建议定期使用「导出数据」功能备份，避免数据丢失</li>
          </ul>
        </div>
      )}
    </div>
  );
}
