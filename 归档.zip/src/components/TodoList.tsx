import { Todo, ThemeMode } from '../types/todo';
import TodoItem from './TodoItem';

interface TodoListProps {
  todos: Todo[];
  onToggle: (id: number) => void;
  onDelete: (id: number) => void;
  theme: ThemeMode;
}

export default function TodoList({ todos, onToggle, onDelete, theme }: TodoListProps) {
  if (todos.length === 0) {
    return (
      <div className="empty-state">
        <div className="empty-illustration">🌱</div>
        <p className="empty-title">暂无待办事项</p>
        <p className="empty-subtitle">点击右上角「⚙️ 功能面板」添加新待办</p>
      </div>
    );
  }

  return (
    <ul className="todo-list">
      {todos.map((todo) => (
        <TodoItem
          key={todo.id}
          todo={todo}
          onToggle={onToggle}
          onDelete={onDelete}
          theme={theme}
        />
      ))}
    </ul>
  );
}
