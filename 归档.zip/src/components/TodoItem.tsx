import { Todo, PRIORITY_CONFIG } from '../types/todo';

interface TodoItemProps {
  todo: Todo;
  onToggle: (id: number) => void;
  onDelete: (id: number) => void;
  theme: 'light' | 'dark';
}

export default function TodoItem({ todo, onToggle, onDelete, theme }: TodoItemProps) {
  const priorityConfig = PRIORITY_CONFIG[todo.priority];
  const isOverdue = todo.deadline && new Date(todo.deadline) < new Date() && !todo.completed;
  const today = new Date().toISOString().split('T')[0];

  const formatDeadline = (dateStr: string) => {
    const date = new Date(dateStr);
    const datePart = date.toLocaleDateString('zh-CN', { month: 'short', day: 'numeric' });
    // Check if time is set (not midnight 00:00)
    const hours = date.getHours();
    const minutes = date.getMinutes();
    if (hours !== 0 || minutes !== 0) {
      const timeStr = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
      return `${datePart} ${timeStr}`;
    }
    return datePart;
  };

  const isToday = todo.deadline && todo.deadline.startsWith(today);

  return (
    <li
      className={`todo-item ${todo.completed ? 'completed' : ''} ${isOverdue ? 'overdue' : ''} ${theme}`}
      style={{
        backgroundColor: theme === 'dark' ? '#2d3748' : priorityConfig.color,
        borderLeft: `4px solid ${priorityConfig.border}`,
      }}
    >
      <div className="todo-content" onClick={() => onToggle(todo.id)}>
        <div className="todo-main">
          <span className="priority-icon">{priorityConfig.icon}</span>
          <span className="todo-text">{todo.text}</span>
        </div>
        <div className="todo-meta">
          {todo.deadline && (
            <span className={`deadline ${isOverdue ? 'overdue' : isToday ? 'today' : ''}`}>
              📅 {formatDeadline(todo.deadline)}
            </span>
          )}
          {todo.reminderMinutes && (
            <span className="reminder-badge">🔔</span>
          )}
        </div>
      </div>
      <button className="delete-btn" onClick={(e) => { e.stopPropagation(); onDelete(todo.id); }}>
        🗑️
      </button>
    </li>
  );
}
