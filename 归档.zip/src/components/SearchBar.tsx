interface SearchBarProps {
  search: string;
  onChange: (search: string) => void;
}

export default function SearchBar({ search, onChange }: SearchBarProps) {
  return (
    <div className="search-bar">
      <span className="search-icon">🔍</span>
      <input
        type="text"
        value={search}
        onChange={(e) => onChange(e.target.value)}
        placeholder="搜索待办事项..."
        className="search-input"
      />
      {search && (
        <button className="search-clear" onClick={() => onChange('')}>
          ✕
        </button>
      )}
    </div>
  );
}
