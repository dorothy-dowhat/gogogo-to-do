import { useState, useEffect, useRef } from 'react';
import { Todo, Priority, Category, PRIORITY_CONFIG, CATEGORY_CONFIG } from '../types/todo';

interface SettingsPanelProps {
  isOpen: boolean;
  onClose: () => void;
  todos: Todo[];
  onAddTodo: (text: string, priority: Priority, category: Category, deadline: string | null, reminderMinutes: number | null) => void;
  onClearCompleted: () => void;
  onImport: (todos: Todo[]) => void;
  notifyPermission?: NotificationPermission;
  onRequestNotification?: () => void;
  onTestNotification?: () => void;
}

export default function SettingsPanel({
  isOpen,
  onClose,
  todos,
  onAddTodo,
  onClearCompleted,
  onImport,
  notifyPermission = 'default',
  onRequestNotification,
  onTestNotification,
}: SettingsPanelProps) {
  const [text, setText] = useState('');
  const [priority, setPriority] = useState<Priority>('medium');
  const [category, setCategory] = useState<Exclude<Category, 'all'>>('life');
  const [deadline, setDeadline] = useState('');
  const [reminderMinutes, setReminderMinutes] = useState<number | null>(null);
  const [importFile, setImportFile] = useState<File | null>(null);
  const panelRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Close on click outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (panelRef.current && !panelRef.current.contains(e.target as Node)) {
        onClose();
      }
    };
    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isOpen, onClose]);

  // Close on Escape
  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) {
      document.addEventListener('keydown', handleEscape);
    }
    return () => document.removeEventListener('keydown', handleEscape);
  }, [isOpen, onClose]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = text.trim();
    if (!trimmed) return;
    onAddTodo(trimmed, priority, category, deadline || null, reminderMinutes);
    setText('');
    setPriority('medium');
    setCategory('life');
    setDeadline('');
    setReminderMinutes(null);
  };

  // Stats
  const total = todos.length;
  const completed = todos.filter((t) => t.completed).length;
  const pending = total - completed;
  const completionRate = total > 0 ? Math.round((completed / total) * 100) : 0;
  const overdue = todos.filter(
    (t) => t.deadline && new Date(t.deadline) < new Date() && !t.completed
  ).length;

  // Export JSON
  const exportJSON = () => {
    const data = JSON.stringify(todos, null, 2);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `gogogo出发喽备份_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Export CSV
  const exportCSV = () => {
    const headers = ['待办内容', '优先级', '分类', '截止日期', '是否完成', '创建时间'];
    const rows = todos.map((t) => [
      t.text,
      PRIORITY_CONFIG[t.priority].label,
      CATEGORY_CONFIG[t.category]?.label || t.category,
      t.deadline || '',
      t.completed ? '已完成' : '未完成',
      t.createdAt,
    ]);
    const csvContent = [headers, ...rows]
      .map((row) => row.map((cell) => `"${cell}"`).join(','))
      .join('\n');
    const BOM = '\uFEFF';
    const blob = new Blob([BOM + csvContent], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `gogogo出发喽_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Export Excel
  const exportExcel = () => {
    const headers = ['待办内容', '优先级', '分类', '截止日期', '是否完成', '创建时间'];
    const rows = todos.map((t) => [
      t.text,
      PRIORITY_CONFIG[t.priority].label,
      CATEGORY_CONFIG[t.category]?.label || t.category,
      t.deadline || '',
      t.completed ? '已完成' : '未完成',
      t.createdAt,
    ]);

    let html = '<table>';
    html += '<tr>' + headers.map(h => `<th>${h}</th>`).join('') + '</tr>';
    rows.forEach(row => {
      html += '<tr>' + row.map(cell => `<td>${cell}</td>`).join('') + '</tr>';
    });
    html += '</table>';

    const blob = new Blob([html], { type: 'application/vnd.ms-excel' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `gogogo出发喽_${new Date().toISOString().split('T')[0]}.xls`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Import
  const handleImport = () => {
    if (!importFile) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const content = e.target?.result as string;
        const imported = JSON.parse(content);
        if (Array.isArray(imported)) {
          const valid = imported.filter(
            (item) =>
              item &&
              typeof item.text === 'string' &&
              typeof item.completed === 'boolean' &&
              ['high', 'medium', 'low'].includes(item.priority)
          );
          if (valid.length > 0) {
            onImport(valid);
            alert(`成功导入 ${valid.length} 条待办`);
          } else {
            alert('文件格式不正确');
          }
        } else {
          alert('文件格式不正确');
        }
      } catch {
        alert('读取文件失败，请确保是有效的 JSON 文件');
      }
    };
    reader.readAsText(importFile);
    setImportFile(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const categories: Exclude<Category, 'all'>[] = ['work', 'study', 'life'];

  if (!isOpen) return null;

  return (
    <div className="settings-overlay">
      <div className="settings-panel" ref={panelRef}>
        <div className="panel-header">
          <h2>⚙️ 功能面板</h2>
          <button className="close-btn" onClick={onClose}>✕</button>
        </div>

        <div className="panel-content">
          {/* Create Todo */}
          <section className="panel-section">
            <h3>✨ 创建待办</h3>
            <form onSubmit={handleSubmit}>
              <input
                ref={inputRef}
                type="text"
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="输入新的待办..."
                className="panel-input"
              />
              <div className="form-row">
                <div className="form-group">
                  <label>优先级</label>
                  <div className="priority-btns">
                    {(['high', 'medium', 'low'] as Priority[]).map((p) => (
                      <button
                        key={p}
                        type="button"
                        className={`priority-btn ${priority === p ? 'active' : ''}`}
                        style={{
                          borderColor: PRIORITY_CONFIG[p].border,
                          backgroundColor: priority === p ? PRIORITY_CONFIG[p].border : 'transparent',
                          color: priority === p ? '#fff' : PRIORITY_CONFIG[p].border,
                        }}
                        onClick={() => setPriority(p)}
                      >
                        {PRIORITY_CONFIG[p].icon} {PRIORITY_CONFIG[p].label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
              <div className="form-row">
                <div className="form-group">
                  <label>分类</label>
                  <div className="category-btns">
                    {categories.map((c) => (
                      <button
                        key={c}
                        type="button"
                        className={`category-btn ${category === c ? 'active' : ''}`}
                        onClick={() => setCategory(c)}
                      >
                        {CATEGORY_CONFIG[c].emoji} {CATEGORY_CONFIG[c].label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
              <div className="form-row">
                <div className="form-group">
                  <label>截止日期</label>
                  <input
                    type="datetime-local"
                    value={deadline}
                    onChange={(e) => setDeadline(e.target.value)}
                    className="deadline-input"
                  />
                </div>
                <div className="form-group">
                  <label>提醒</label>
                  <select
                    value={reminderMinutes ?? ''}
                    onChange={(e) => setReminderMinutes(e.target.value ? Number(e.target.value) : null)}
                    className="reminder-select"
                  >
                    <option value="">不提醒</option>
                    <option value="15">提前15分钟</option>
                    <option value="30">提前30分钟</option>
                    <option value="60">提前1小时</option>
                    <option value="120">提前2小时</option>
                    <option value="1440">提前1天</option>
                  </select>
                </div>
              </div>
              <button type="submit" className="add-btn">✨ 添加待办</button>
            </form>
          </section>

          {/* Stats */}
          <section className="panel-section">
            <h3>📊 数据统计</h3>
            <div className="stats-grid">
              <div className="stat-card">
                <span className="stat-value">{total}</span>
                <span className="stat-label">总待办</span>
              </div>
              <div className="stat-card completed">
                <span className="stat-value">{completed}</span>
                <span className="stat-label">已完成</span>
              </div>
              <div className="stat-card pending">
                <span className="stat-value">{pending}</span>
                <span className="stat-label">待完成</span>
              </div>
              <div className="stat-card rate">
                <span className="stat-value">{completionRate}%</span>
                <span className="stat-label">完成率</span>
              </div>
            </div>
            {overdue > 0 && (
              <p className="overdue-hint">⚠️ 有 {overdue} 项待办已过期</p>
            )}
            {completed > 0 && (
              <button className="clear-btn" onClick={onClearCompleted}>
                🧹 清空已完成
              </button>
            )}
          </section>

          {/* Notification Settings */}
          <section className="panel-section">
            <h3>🔔 消息通知</h3>
            <p className="notification-status">
              当前状态：{' '}
              {notifyPermission === 'granted'
                ? '✅ 已开启'
                : notifyPermission === 'denied'
                ? '⚠️ 已拒绝'
                : '⏳ 未设置'}
            </p>

            {notifyPermission === 'granted' && (
              <>
                <div className="notification-on-info">
                  <p>任务到期前会收到提醒通知</p>
                </div>
                <button className="notify-test-btn" onClick={onTestNotification}>
                  📨 发送测试通知
                </button>
                <p className="notification-hint">关闭通知请在浏览器设置中操作</p>
              </>
            )}

            {notifyPermission === 'denied' && (
              <div className="notification-denied-info">
                <p>通知权限被浏览器拦截</p>
                <p className="notification-hint">请手动在浏览器设置中允许通知</p>
                <button className="notify-enable-btn" onClick={() => {
                  alert('操作指南：\n\nChrome/Edge：\n1. 点击地址栏左侧的锁定图标\n2. 选择「通知」→ 「允许」\n\nSafari：\n1. 打开 Safari 偏好设置\n2. 选择「网站」标签\n3. 找到本网站的通知权限并允许');
                }}>
                  📖 查看开启方法
                </button>
              </div>
            )}

            {notifyPermission !== 'granted' && notifyPermission !== 'denied' && (
              <>
                <button className="notify-enable-btn" onClick={onRequestNotification}>
                  🔔 开启消息通知
                </button>
                <p className="notification-hint">开启后，任务到期前会收到提醒</p>
              </>
            )}
          </section>

          {/* Data Management */}
          <section className="panel-section">
            <h3>💾 数据管理</h3>
            <div className="data-btns">
              <button className="data-btn" onClick={exportJSON}>📄 JSON</button>
              <button className="data-btn" onClick={exportCSV}>📊 CSV</button>
              <button className="data-btn" onClick={exportExcel}>📋 Excel</button>
            </div>
            <div className="import-row">
              <input
                ref={fileInputRef}
                type="file"
                accept=".json"
                onChange={(e) => setImportFile(e.target.files?.[0] || null)}
                style={{ display: 'none' }}
              />
              <button className="data-btn import" onClick={() => fileInputRef.current?.click()}>
                📂 导入 JSON
              </button>
              {importFile && (
                <button className="data-btn confirm" onClick={handleImport}>
                  确认导入
                </button>
              )}
            </div>
            {importFile && <p className="import-filename">已选择: {importFile.name}</p>}
          </section>

          {/* Data Security */}
          <section className="panel-section">
            <h3>🔒 数据安全说明</h3>
            <div className="security-info">
              <p>• 数据仅保存在您当前浏览器的本地，不会上传到服务器</p>
              <p>• 关闭浏览器、重启电脑，数据不会丢失</p>
              <p>• 以下情况会导致数据丢失：</p>
              <ol>
                <li>手动清除浏览器缓存、网站数据</li>
                <li>使用无痕/隐私模式访问本网站</li>
                <li>更换设备、更换浏览器访问</li>
                <li>卸载或重置浏览器</li>
              </ol>
              <p>• 建议定期使用「导出数据」功能备份</p>
            </div>
            <div className="privacy-notice">
              <p>🔒 通知权限仅用于待办提醒，不会发送任何广告或推广信息</p>
              <p>📂 所有代码开源透明，您可随时查看</p>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}
