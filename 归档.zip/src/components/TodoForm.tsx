import { useState } from 'react';
import { Priority, Category, PRIORITY_CONFIG, CATEGORY_CONFIG } from '../types/todo';

interface TodoFormProps {
  onAdd: (text: string, priority: Priority, category: Category, deadline: string | null, reminderMinutes: number | null) => void;
}

export default function TodoForm({ onAdd }: TodoFormProps) {
  const [text, setText] = useState('');
  const [priority, setPriority] = useState<Priority>('medium');
  const [category, setCategory] = useState<Exclude<Category, 'all'>>('life');
  const [deadline, setDeadline] = useState('');
  const [reminderMinutes, setReminderMinutes] = useState<number | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = text.trim();
    if (!trimmed) return;
    onAdd(trimmed, priority, category, deadline || null, reminderMinutes);
    setText('');
    setPriority('medium');
    setCategory('life');
    setDeadline('');
    setReminderMinutes(null);
  };

  return (
    <form className="todo-form" onSubmit={handleSubmit}>
      <div className="form-main">
        <input
          type="text"
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="输入新的待办事项..."
          autoComplete="off"
          className="todo-input"
        />
      </div>
      <div className="form-options">
        <div className="form-group">
          <label>优先级</label>
          <div className="priority-buttons">
            {(['high', 'medium', 'low'] as Priority[]).map((p) => (
              <button
                key={p}
                type="button"
                className={`priority-btn ${priority === p ? 'active' : ''}`}
                style={{
                  backgroundColor: priority === p ? PRIORITY_CONFIG[p].border : 'transparent',
                  color: priority === p ? '#fff' : PRIORITY_CONFIG[p].border,
                }}
                onClick={() => setPriority(p)}
              >
                {PRIORITY_CONFIG[p].icon} {PRIORITY_CONFIG[p].label}
              </button>
            ))}
          </div>
        </div>
        <div className="form-group">
          <label>分类</label>
          <div className="category-buttons">
            {(Object.keys(CATEGORY_CONFIG) as Exclude<Category, 'all'>[]).map((c) => (
              <button
                key={c}
                type="button"
                className={`category-btn ${category === c ? 'active' : ''}`}
                onClick={() => setCategory(c)}
              >
                {CATEGORY_CONFIG[c].emoji} {CATEGORY_CONFIG[c].label}
              </button>
            ))}
          </div>
        </div>
        <div className="form-group">
          <label>截止日期</label>
          <input
            type="datetime-local"
            value={deadline}
            onChange={(e) => setDeadline(e.target.value)}
            className="deadline-input"
          />
        </div>
        <div className="form-group">
          <label>提醒</label>
          <select
            value={reminderMinutes ?? ''}
            onChange={(e) => setReminderMinutes(e.target.value ? Number(e.target.value) : null)}
            className="reminder-select"
          >
            <option value="">不提醒</option>
            <option value="15">提前15分钟</option>
            <option value="30">提前30分钟</option>
            <option value="60">提前1小时</option>
            <option value="120">提前2小时</option>
            <option value="1440">提前1天</option>
          </select>
        </div>
      </div>
      <button type="submit" className="add-btn">✨ 添加待办</button>
    </form>
  );
}
