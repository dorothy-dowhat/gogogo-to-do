import { Category, CATEGORY_CONFIG } from '../types/todo';

interface CategoryTabsProps {
  category: Category;
  onChange: (category: Category) => void;
}

export default function CategoryTabs({ category, onChange }: CategoryTabsProps) {
  const categories: Category[] = ['all', 'work', 'study', 'life'];

  const getConfig = (c: Category) => {
    if (c === 'all') return { label: '全部', emoji: '🌈' };
    return CATEGORY_CONFIG[c as Exclude<Category, 'all'>];
  };

  return (
    <div className="category-tabs">
      {categories.map((c) => (
        <button
          key={c}
          className={`category-tab ${category === c ? 'active' : ''}`}
          onClick={() => onChange(c)}
        >
          {getConfig(c).emoji} {getConfig(c).label}
        </button>
      ))}
    </div>
  );
}
