import { ThemeMode } from '../types/todo';

interface ThemeToggleProps {
  theme: ThemeMode;
  onToggle: () => void;
}

export default function ThemeToggle({ theme, onToggle }: ThemeToggleProps) {
  return (
    <button className="theme-toggle" onClick={onToggle} title="切换主题">
      {theme === 'light' ? '🌙' : '☀️'}
    </button>
  );
}
