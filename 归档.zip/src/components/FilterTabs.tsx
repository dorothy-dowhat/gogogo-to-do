import { FilterType } from '../types/todo';

interface FilterTabsProps {
  filter: FilterType;
  onChange: (filter: FilterType) => void;
}

const filterLabels: Record<FilterType, { label: string; emoji: string }> = {
  all: { label: '全部', emoji: '📋' },
  completed: { label: '已完成', emoji: '✅' },
  pending: { label: '待完成', emoji: '⏳' },
};

export default function FilterTabs({ filter, onChange }: FilterTabsProps) {
  return (
    <div className="filter-tabs">
      {(Object.keys(filterLabels) as FilterType[]).map((f) => (
        <button
          key={f}
          className={`filter-tab ${filter === f ? 'active' : ''}`}
          onClick={() => onChange(f)}
        >
          {filterLabels[f].emoji} {filterLabels[f].label}
        </button>
      ))}
    </div>
  );
}
