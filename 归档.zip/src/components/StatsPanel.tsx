import { Todo, PRIORITY_CONFIG } from '../types/todo';

interface StatsPanelProps {
  todos: Todo[];
  onClearCompleted: () => void;
}

export default function StatsPanel({ todos, onClearCompleted }: StatsPanelProps) {
  const total = todos.length;
  const completed = todos.filter((t) => t.completed).length;
  const pending = total - completed;
  const completionRate = total > 0 ? Math.round((completed / total) * 100) : 0;

  const priorityCount = {
    high: todos.filter((t) => t.priority === 'high').length,
    medium: todos.filter((t) => t.priority === 'medium').length,
    low: todos.filter((t) => t.priority === 'low').length,
  };

  const overdue = todos.filter(
    (t) => t.deadline && new Date(t.deadline) < new Date() && !t.completed
  ).length;

  return (
    <div className="stats-panel">
      <div className="stats-header">
        <h3>📊 数据统计</h3>
        <div className="stats-actions">
          {completed > 0 && (
            <button className="clear-btn" onClick={onClearCompleted}>
              🧹 清空已完成
            </button>
          )}
        </div>
      </div>

      <div className="stats-grid">
        <div className="stat-card">
          <span className="stat-value">{total}</span>
          <span className="stat-label">总待办</span>
        </div>
        <div className="stat-card completed">
          <span className="stat-value">{completed}</span>
          <span className="stat-label">已完成</span>
        </div>
        <div className="stat-card pending">
          <span className="stat-value">{pending}</span>
          <span className="stat-label">待完成</span>
        </div>
        <div className="stat-card rate">
          <span className="stat-value">{completionRate}%</span>
          <span className="stat-label">完成率</span>
        </div>
      </div>

      <div className="priority-distribution">
        <span className="distribution-title">优先级分布</span>
        <div className="distribution-bars">
          {(['high', 'medium', 'low'] as const).map((p) => (
            <div key={p} className="distribution-item">
              <span className="dist-label">{PRIORITY_CONFIG[p].icon}</span>
              <div className="dist-bar-bg">
                <div
                  className="dist-bar"
                  style={{
                    width: total > 0 ? `${(priorityCount[p] / total) * 100}%` : '0%',
                    backgroundColor: PRIORITY_CONFIG[p].border,
                  }}
                />
              </div>
              <span className="dist-count">{priorityCount[p]}</span>
            </div>
          ))}
        </div>
      </div>

      {overdue > 0 && (
        <div className="overdue-warning">
          ⚠️ 有 {overdue} 项待办已过期
        </div>
      )}
    </div>
  );
}
