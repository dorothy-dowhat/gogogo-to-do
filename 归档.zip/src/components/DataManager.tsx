import { useState, useRef, useEffect } from 'react';
import { Todo, PRIORITY_CONFIG, CATEGORY_CONFIG } from '../types/todo';

interface DataManagerProps {
  todos: Todo[];
  onImport: (todos: Todo[]) => void;
}

export default function DataManager({ todos, onImport }: DataManagerProps) {
  const [isOpen, setIsOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Close menu when clicking outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Export as JSON
  const exportJSON = () => {
    const data = JSON.stringify(todos, null, 2);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `gogogo出发喽备份_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
    setIsOpen(false);
  };

  // Export as CSV
  const exportCSV = () => {
    const headers = ['待办内容', '优先级', '分类', '截止日期', '是否完成', '创建时间'];
    const rows = todos.map((t) => [
      t.text,
      PRIORITY_CONFIG[t.priority].label,
      CATEGORY_CONFIG[t.category]?.label || t.category,
      t.deadline || '',
      t.completed ? '已完成' : '未完成',
      t.createdAt,
    ]);

    const csvContent = [headers, ...rows]
      .map((row) => row.map((cell) => `"${cell}"`).join(','))
      .join('\n');

    const BOM = '\uFEFF';
    const blob = new Blob([BOM + csvContent], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `gogogo出发喽_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    setIsOpen(false);
  };

  // Import from JSON file
  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const content = event.target?.result as string;
        const imported = JSON.parse(content);

        if (Array.isArray(imported)) {
          const validTodos = imported.filter(
            (item) =>
              item &&
              typeof item.text === 'string' &&
              typeof item.completed === 'boolean' &&
              ['high', 'medium', 'low'].includes(item.priority)
          );

          if (validTodos.length > 0) {
            onImport(validTodos);
            alert(`成功导入 ${validTodos.length} 条待办`);
          } else {
            alert('文件格式不正确');
          }
        } else {
          alert('文件格式不正确');
        }
      } catch {
        alert('读取文件失败，请确保是有效的 JSON 文件');
      }
    };
    reader.readAsText(file);

    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
    setIsOpen(false);
  };

  return (
    <div className="data-manager" ref={menuRef}>
      <button
        className="data-manager-btn"
        onClick={() => setIsOpen(!isOpen)}
        title="数据管理"
      >
        📤
      </button>

      {isOpen && (
        <div className="data-manager-dropdown">
          <div className="dropdown-section">
            <span className="dropdown-label">📤 导出数据</span>
            <button className="dropdown-btn" onClick={exportJSON}>
              📄 导出 JSON 备份
            </button>
            <button className="dropdown-btn" onClick={exportCSV}>
              📊 导出 Excel/CSV
            </button>
          </div>

          <div className="dropdown-divider" />

          <div className="dropdown-section">
            <span className="dropdown-label">📥 导入数据</span>
            <input
              ref={fileInputRef}
              type="file"
              accept=".json"
              onChange={handleImport}
              style={{ display: 'none' }}
            />
            <button
              className="dropdown-btn"
              onClick={() => fileInputRef.current?.click()}
            >
              📂 导入 JSON
            </button>
            <p className="dropdown-hint">导入将覆盖当前数据</p>
          </div>
        </div>
      )}
    </div>
  );
}
