export type Priority = 'high' | 'medium' | 'low';
export type Category = 'all' | 'work' | 'study' | 'life';
export type FilterType = 'all' | 'completed' | 'pending';
export type ThemeMode = 'light' | 'dark';

export interface Todo {
  id: number;
  text: string;
  completed: boolean;
  priority: Priority;
  category: Exclude<Category, 'all'>;
  deadline: string | null; // ISO datetime-local string (YYYY-MM-DDTHH:mm)
  createdAt: string; // ISO date string
  completedAt: string | null; // ISO date string, 记录完成时间
  reminderMinutes: number | null; // 提前多少分钟提醒，null表示不提醒
}

export const PRIORITY_CONFIG = {
  high: { label: '高', color: '#ffebee', border: '#ef5350', icon: '🔴' },
  medium: { label: '中', color: '#fff3e0', border: '#ff9800', icon: '🟠' },
  low: { label: '低', color: '#fffde7', border: '#ffeb3b', icon: '🟡' },
} as const;

export const CATEGORY_CONFIG = {
  work: { label: '工作', emoji: '💼' },
  study: { label: '学习', emoji: '📚' },
  life: { label: '生活', emoji: '🏠' },
} as const;
