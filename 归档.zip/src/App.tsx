import { useState, useMemo, useEffect } from 'react';
import { Todo, Priority, Category, ThemeMode } from './types/todo';
import TodoList from './components/TodoList';
import SettingsPanel from './components/SettingsPanel';
import confetti from 'canvas-confetti';
import './index.css';

const STORAGE_KEY = 'mint-todo-app-data';
const THEME_KEY = 'mint-todo-app-theme';

function loadTodos(): Todo[] {
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    if (data) {
      const parsed = JSON.parse(data);
      if (Array.isArray(parsed)) {
        return parsed.map((item: Todo) => ({
          ...item,
          category: item.category || 'life',
          deadline: item.deadline || null,
          createdAt: item.createdAt || new Date().toISOString(),
          completedAt: item.completedAt || null,
          reminderMinutes: item.reminderMinutes ?? null,
        }));
      }
    }
    return [];
  } catch {
    return [];
  }
}

function saveTodos(todos: Todo[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(todos));
}

function loadTheme(): ThemeMode {
  try {
    return (localStorage.getItem(THEME_KEY) as ThemeMode) || 'light';
  } catch {
    return 'light';
  }
}

function saveTheme(theme: ThemeMode) {
  localStorage.setItem(THEME_KEY, theme);
}

// Sort pending todos: by deadline ascending (nearest first), no deadline at end
// Within same day: high priority first, then by time descending (later time first)
function sortPendingTodos(todos: Todo[]): Todo[] {
  const priorityOrder: Record<string, number> = { high: 0, medium: 1, low: 2 };

  // Separate todos with deadline vs without
  const withDeadline = todos.filter((t) => t.deadline);
  const withoutDeadline = todos.filter((t) => !t.deadline);

  // Sort todos with deadline
  withDeadline.sort((a, b) => {
    const dateA = new Date(a.deadline!);
    const dateB = new Date(b.deadline!);

    // Check if same day (compare year, month, day)
    const isSameDay =
      dateA.getFullYear() === dateB.getFullYear() &&
      dateA.getMonth() === dateB.getMonth() &&
      dateA.getDate() === dateB.getDate();

    if (isSameDay) {
      // Same day: high priority first, then by time descending
      if (a.priority === 'high' && b.priority !== 'high') return -1;
      if (b.priority === 'high' && a.priority !== 'high') return 1;

      // Same priority on same day: time descending (later time first)
      if (a.priority === b.priority) {
        return dateB.getTime() - dateA.getTime();
      }
    }

    // Different days: deadline ascending (nearest first)
    return dateA.getTime() - dateB.getTime();
  });

  // Without deadline: priority order
  withoutDeadline.sort((a, b) => priorityOrder[a.priority] - priorityOrder[b.priority]);

  return [...withDeadline, ...withoutDeadline];
}

// Sort completed todos: by completedAt descending (most recent first)
function sortCompletedTodos(todos: Todo[]): Todo[] {
  return [...todos].sort((a, b) => {
    if (!a.completedAt || !b.completedAt) {
      if (!a.completedAt && b.completedAt) return 1;
      if (a.completedAt && !b.completedAt) return -1;
      return 0;
    }
    return new Date(b.completedAt).getTime() - new Date(a.completedAt).getTime();
  });
}

type FilterTab = 'all' | 'completed' | 'pending' | 'work' | 'study' | 'life';

export default function App() {
  const [todos, setTodos] = useState<Todo[]>(loadTodos);
  const [filter, setFilter] = useState<FilterTab>('pending');
  const [searchQuery, setSearchQuery] = useState('');
  const [theme, setTheme] = useState<ThemeMode>(loadTheme);
  const [isPanelOpen, setIsPanelOpen] = useState(false);
  const [mounted, setMounted] = useState(false);
  const [notifiedReminders, setNotifiedReminders] = useState<Set<number>>(new Set());
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [showInstallBtn, setShowInstallBtn] = useState(false);
  const [isIOS, setIsIOS] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  // Notification permission state - 'unknown' means not checked yet, will sync with browser on mount
  const [notifyPermission, setNotifyPermission] = useState<NotificationPermission>('default');

  // Sync notification permission with browser on mount and whenever visibility changes
  useEffect(() => {
    setMounted(true);

    // Sync notification permission with browser
    const syncPermission = () => {
      if ('Notification' in window) {
        setNotifyPermission(Notification.permission);
      }
    };

    syncPermission();

    // Re-check permission when window becomes visible (user may have changed settings)
    document.addEventListener('visibilitychange', syncPermission);

    // Detect iOS/iPadOS
    const iOS = /iPad|iPhone|iPod/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
    setIsIOS(iOS);

    // Detect mobile device (including Android phones and tablets)
    const mobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
    setIsMobile(mobile);

    // Detect if already installed as PWA
    const isStandalone = window.matchMedia('(display-mode: standalone)').matches || (window.navigator as any).standalone === true;
    if (isStandalone) {
      setShowInstallBtn(false);
      return;
    }

    // For all mobile devices (iOS/Android): show manual install instructions
    if (mobile) {
      setShowInstallBtn(true);
      return;
    }

    // For desktop browsers: listen for PWA install prompt (Chrome/Edge)
    const handleBeforeInstall = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setShowInstallBtn(true);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstall);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstall);
      document.removeEventListener('visibilitychange', syncPermission);
    };
  }, []);

  // Request notification permission ONLY when user clicks the button
  const handleRequestNotification = async () => {
    if (!('Notification' in window)) {
      alert('您的浏览器不支持通知功能');
      return;
    }

    const permission = await Notification.requestPermission();
    setNotifyPermission(permission);

    if (permission === 'granted') {
      // Show a test notification to confirm it works
      new Notification('✅ 通知已开启', {
        body: '您将在任务到期前收到提醒通知',
        icon: 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><text y=".9em" font-size="90">🔔</text></svg>',
      });
    } else if (permission === 'denied') {
      alert('通知权限被浏览器拦截。\n\n请手动到浏览器设置中开启：\n1. 点击地址栏左侧的锁定图标\n2. 选择「通知」\n3. 改为「允许」');
    } else {
      // Default - user closed the dialog
    }
  };

  // Send test notification (for settings panel)
  const handleTestNotification = () => {
    if (Notification.permission === 'granted') {
      new Notification('🔔 测试通知', {
        body: '这是一条测试通知，功能正常！',
        icon: 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><text y=".9em" font-size="90">✅</text></svg>',
      });
    } else {
      alert('请先开启通知权限');
    }
  };

  const handleInstall = async () => {
    if (isMobile) {
      // Mobile: show instructions
      if (isIOS) {
        alert('请按以下步骤安装：\n\n1.  点击 Safari 底部的「分享」按钮\n2.  向下滚动找到「添加到主屏幕」\n3.  点击右上角「添加」');
      } else {
        alert('请按以下步骤安装：\n\n1.  点击浏览器右上角菜单\n2.  选择「添加到主屏幕」\n3.  点击「添加」');
      }
      return;
    }

    if (!deferredPrompt) {
      alert('安装提示尚未准备就绪。请先与网页有些互动（如滚动页面），然后重试。');
      return;
    }

    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') {
      setShowInstallBtn(false);
    }
    setDeferredPrompt(null);
  };

  useEffect(() => {
    saveTodos(todos);
  }, [todos]);

  useEffect(() => {
    saveTheme(theme);
    document.documentElement.setAttribute('data-theme', theme);
  }, [theme]);

  // Check for due reminders every minute
  useEffect(() => {
    const checkReminders = () => {
      if (!('Notification' in window) || Notification.permission !== 'granted') return;

      const now = Date.now();
      todos.forEach((todo) => {
        if (
          todo.completed ||
          !todo.deadline ||
          !todo.reminderMinutes ||
          notifiedReminders.has(todo.id)
        ) {
          return;
        }

        const deadlineTime = new Date(todo.deadline).getTime();
        const reminderTime = deadlineTime - todo.reminderMinutes * 60 * 1000;

        if (now >= reminderTime && now < deadlineTime) {
          new Notification('待办提醒', {
            body: `「${todo.text}」将在 ${todo.reminderMinutes} 分钟后到期`,
            icon: 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><text y=".9em" font-size="90">⏰</text></svg>',
          });
          setNotifiedReminders((prev) => new Set(prev).add(todo.id));
        }
      });
    };

    checkReminders();
    const interval = setInterval(checkReminders, 60000);
    return () => clearInterval(interval);
  }, [todos, notifiedReminders]);

  const addTodo = (text: string, priority: Priority, cat: Category, deadline: string | null, reminderMinutes: number | null) => {
    const newTodo: Todo = {
      id: Date.now(),
      text,
      completed: false,
      priority,
      category: cat as Exclude<Category, 'all'>,
      deadline,
      createdAt: new Date().toISOString(),
      completedAt: null,
      reminderMinutes,
    };
    setTodos((prev) => [newTodo, ...prev]);
  };

  const deleteTodo = (id: number) => {
    setTodos((prev) => prev.filter((todo) => todo.id !== id));
  };

  const toggleTodo = (id: number) => {
    setTodos((prev) =>
      prev.map((todo) => {
        if (todo.id !== id) return todo;
        const isCompleting = !todo.completed;
        if (isCompleting && todo.priority === 'high') {
          // Fire pastel confetti for high priority completion
          confetti({
            particleCount: 80,
            spread: 70,
            colors: ['#ffb3ba', '#ffdfba', '#ffffba', '#baffc9', '#bae1ff'],
            disableForReducedMotion: true,
          });
        }
        return {
          ...todo,
          completed: !todo.completed,
          completedAt: isCompleting ? new Date().toISOString() : null,
        };
      })
    );
  };

  const clearCompleted = () => {
    setTodos((prev) => prev.filter((todo) => !todo.completed));
  };

  const handleImport = (importedTodos: Todo[]) => {
    setTodos(importedTodos);
  };

  const toggleTheme = () => {
    setTheme((prev) => (prev === 'light' ? 'dark' : 'light'));
  };

  const handleOpenPanel = () => {
    setIsPanelOpen(true);
  };

  const filteredTodos = useMemo(() => {
    let result = todos;

    // Unified filter
    if (filter === 'completed') {
      result = result.filter((todo) => todo.completed);
    } else if (filter === 'pending') {
      result = result.filter((todo) => !todo.completed);
    } else if (filter === 'work' || filter === 'study' || filter === 'life') {
      result = result.filter((todo) => todo.category === filter);
    }
    // 'all' shows everything

    // Search filter
    if (searchQuery.trim()) {
      const searchLower = searchQuery.toLowerCase();
      result = result.filter((todo) =>
        todo.text.toLowerCase().includes(searchLower)
      );
    }

    // Sort based on filter type
    if (filter === 'completed') {
      return sortCompletedTodos(result);
    } else if (filter === 'pending' || filter === 'all') {
      // pending: sort by deadline then priority
      // all: pending first (sorted by deadline+priority), then completed (sorted by completedAt)
      const pending = result.filter((t) => !t.completed);
      const completed = result.filter((t) => t.completed);
      return [...sortPendingTodos(pending), ...sortCompletedTodos(completed)];
    } else {
      // category filters: pending first, then completed
      const pending = result.filter((t) => !t.completed);
      const completed = result.filter((t) => t.completed);
      return [...sortPendingTodos(pending), ...sortCompletedTodos(completed)];
    }
  }, [todos, filter, searchQuery]);

  // Stats for counts
  const total = todos.length;
  const completed = todos.filter((t) => t.completed).length;
  const pending = total - completed;
  const workCount = todos.filter((t) => t.category === 'work').length;
  const studyCount = todos.filter((t) => t.category === 'study').length;
  const lifeCount = todos.filter((t) => t.category === 'life').length;

  return (
    <div className={`app ${theme} ${mounted ? 'mounted' : ''}`}>
      <div className="background-effects">
        <div className="gradient-orb orb-1" />
        <div className="gradient-orb orb-2" />
        <div className="gradient-orb orb-3" />
      </div>

      <div className="container">
        {/* Header - Left: Settings | Center: Title | Right: Theme */}
        <header className="app-header">
          <div className="header-top">
            <button
              className="settings-btn icon-only"
              onClick={handleOpenPanel}
              title="功能面板"
            >
              ⚙️
            </button>

            <h1>gogogo</h1>

            <button
              className="theme-toggle-btn"
              onClick={toggleTheme}
              title={theme === 'light' ? '切换深色模式' : '切换浅色模式'}
            >
              {theme === 'light' ? '🌙' : '☀️'}
            </button>
            {showInstallBtn && (
              <button
                className="install-btn"
                onClick={handleInstall}
                title="安装应用到桌面"
              >
                📲
              </button>
            )}
          </div>
        </header>

        {/* Mobile Install Banner */}
        {showInstallBtn && isMobile && (
          <div className="mobile-install-banner" onClick={handleInstall}>
            <span>📱 戳此安装到主屏幕，下次快速访问</span>
          </div>
        )}

        {/* Filter Bar - 6 buttons */}
        <div className="filter-bar">
          <button
            className={`filter-btn pending ${filter === 'pending' ? 'active' : ''}`}
            onClick={() => setFilter('pending')}
          >
            <strong>{pending}</strong> 待完成
          </button>
          <button
            className={`filter-btn ${filter === 'all' ? 'active' : ''}`}
            onClick={() => setFilter('all')}
          >
            <strong>{total}</strong> 总待办
          </button>
          <button
            className={`filter-btn completed ${filter === 'completed' ? 'active' : ''}`}
            onClick={() => setFilter('completed')}
          >
            <strong>{completed}</strong> 已完成
          </button>
          <button
            className={`filter-btn work ${filter === 'work' ? 'active' : ''}`}
            onClick={() => setFilter('work')}
          >
            💼 工作 <strong>{workCount}</strong>
          </button>
          <button
            className={`filter-btn study ${filter === 'study' ? 'active' : ''}`}
            onClick={() => setFilter('study')}
          >
            📚 学习 <strong>{studyCount}</strong>
          </button>
          <button
            className={`filter-btn life ${filter === 'life' ? 'active' : ''}`}
            onClick={() => setFilter('life')}
          >
            🏠 生活 <strong>{lifeCount}</strong>
          </button>
        </div>

        {/* Search Bar */}
        <div className="main-search-bar">
          <span className="search-icon">🔍</span>
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="搜索待办..."
            className="main-search-input"
          />
          {searchQuery && (
            <button className="search-clear" onClick={() => setSearchQuery('')}>✕</button>
          )}
        </div>

        {/* Main Todo List */}
        <main className="todo-section">
          <TodoList
            todos={filteredTodos}
            onToggle={toggleTodo}
            onDelete={deleteTodo}
            theme={theme}
          />
        </main>

        {/* Footer */}
        <footer className="app-footer">
          <p>gogogo出发喽～记录每一步小目标 🚀</p>
        </footer>
      </div>

      {/* Settings Panel */}
      <SettingsPanel
        isOpen={isPanelOpen}
        onClose={() => setIsPanelOpen(false)}
        todos={todos}
        onAddTodo={addTodo}
        onClearCompleted={clearCompleted}
        onImport={handleImport}
        notifyPermission={notifyPermission}
        onRequestNotification={handleRequestNotification}
        onTestNotification={handleTestNotification}
      />
    </div>
  );
}
